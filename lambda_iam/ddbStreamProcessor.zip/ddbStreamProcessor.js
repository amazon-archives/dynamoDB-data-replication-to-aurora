'use strict';

const AWS = require('aws-sdk');
const firehose = new AWS.Firehose({ region: 'us-east-1' });

exports.handler = (event, context, callback) => {

    var fireHoseInput = [];
    event.Records.forEach((record) => {

        console.log(record.eventID);
        console.log(record.eventName);
        console.log(record.dynamodb.NewImage);

        if (record.eventName == "INSERT") {
            fireHoseInput.push({ Data: JSON.stringify(record.dynamodb.NewImage) });
        }
    });

    var params = {
        DeliveryStreamName: 'webAnalytics',
        Records: fireHoseInput
    };

    firehose.putRecordBatch(params, function (err, data) {
        if (err) console.log(err, err.stack); // an error occurred
        else console.log(data);           // successful response
    });


    callback(null, `Successfully processed records.`);

};


